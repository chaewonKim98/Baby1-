import java.util.Scanner;

public class ex03 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("�� �Է�: ");
		int dan = scan.nextInt();
		System.out.print("���� �Է�: ");
		int bum = scan.nextInt();
		
		for(int i = 1;i<=bum;i++) {
			System.out.println(dan+" * "+i+" = "+dan*i);
		}
		
		
		
		
	}

}
