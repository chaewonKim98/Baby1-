
public class ex05 {

	public static void main(String[] args) {
		for(int i = 2;i<=9;i++) {
			System.out.println('\t');
			System.out.print(i+"�� : ");
			
			for(int j = 1; j<=9;j++) {
				
				System.out.print(i+"*"+j+"="+i*j+" ");
				
			}
		}

	}

}
