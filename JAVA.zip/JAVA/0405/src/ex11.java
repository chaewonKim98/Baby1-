
public class ex11 {

	public static void main(String[] args) {
		for(int i = 1; i<=5; i++) {
			//���� �ݺ���
			for(int j = i; j<=5; j++) {
				System.out.print(" ");
			}for(int j = 1; j<=i; j++) {
				System.out.print("*");
			}System.out.println();
		}

	}

}
