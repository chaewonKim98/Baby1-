
public class ex02 {

	public static void main(String[] args) {
		for(int i = 1;i<=9;i++) {
			System.out.println("2*"+i+"="+2*i+" ");
		}

	}

}
