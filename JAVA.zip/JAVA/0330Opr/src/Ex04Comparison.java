
public class Ex04Comparison {

	public static void main(String[] args) {
		int num1 = 3;
		int num2 = 10;
		
		System.out.println(num1 == num2);
		System.out.println(num1 != num2);
		System.out.println(num1 > num2);
		System.out.println(num1 < num2);
		
		
		String str1 = "Hello";
		String str2 = "Hello";
		//���ں�
		System.out.println(str1.equals(str2));
		
		
		
	}

}
