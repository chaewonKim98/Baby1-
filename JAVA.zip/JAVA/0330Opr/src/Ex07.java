import java.util.Scanner;

public class Ex07 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("�뵿�ð��� �Է��ϼ���: ");
		int time = scan.nextInt();
		int pay = 5000;
		float bonus = 5000*1.5f;
		int num2 = time-8;
		int num3 = 40000;
		System.out.print("�� �ӱ��� ");
		System.out.print(time>8?(int)(num3+(num2*bonus)):time*pay);
		System.out.println("�� �Դϴ�.");
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
