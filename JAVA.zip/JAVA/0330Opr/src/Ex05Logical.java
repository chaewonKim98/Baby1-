
public class Ex05Logical {

	public static void main(String[] args) {
		int num1 = 3;
		int num2 = 10;
		System.out.println((num1>num2)&&(num1<num2));  //AND
		System.out.println((num1>num2)||(num1<num2));  //OR

	}

}
