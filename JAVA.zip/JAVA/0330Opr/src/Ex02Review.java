import java.util.Scanner;

public class Ex02Review {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Java���� �Է�>>> ");
		int java = scan.nextInt();
		
		System.out.print("Web���� �Է�>>> ");
		int web = scan.nextInt();
		
		System.out.print("Android���� �Է�>>> ");
		int android = scan.nextInt();
		
		int sum_1 = java+web+android;
		int avg_1 = sum_1/3;
		System.out.println("�հ�: "+sum_1);
		System.out.println("���: "+ avg_1);
	}

}
