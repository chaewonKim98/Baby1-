
public class Ex01If�� {

	public static void main(String[] args) {
		int num = 4;
		
		if(num == 3) {
			System.out.println("3�Դϴ�.");
		}else if(num !=3) {
			System.out.println("3�� �ƴմϴ�.");
		}else {
			System.out.println("num�� ���ڰ� �ƴϴ�.");
		}
		
		
		
		
		
		
		
		
	
	
		
		
		

	}

}
