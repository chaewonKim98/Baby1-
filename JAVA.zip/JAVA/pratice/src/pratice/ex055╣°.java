package pratice;

public class ex055�� {

	public static void main(String[] args) {
		int sum = 0;
		for(int i =77, j=1; i>=1; i--,j++) {
			sum+=(i*j);
		}
		System.out.println(sum);
	}

}
