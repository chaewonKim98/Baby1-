package pratice;

public class ex2110�� {

	public static void main(String[] args) {
		System.out.println("����");
		int[][] B = new int[5][5];
		int num = 1;
		for(int i=0;i<B.length; i++) {
			for(int j=0; j<B.length; j++) {
				B[i][j] = num;
				num++;
				System.out.print(B[i][j]+"\t");
			}
			System.out.println();
		}
		System.out.println("90�� ȸ��");
		
		for(int i=B.length-1; i>=0; i--) {
			for(int j=0; j<B.length; j++) {
				System.out.print(B[j][i]+"\t");
			}
			System.out.println();
		}

	}

}
