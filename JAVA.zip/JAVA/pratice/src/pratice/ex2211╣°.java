package pratice;

import java.util.Scanner;

public class ex2211�� {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		
		while(true) {
			
		System.out.print("A�Է�>> ");
		int A = scan.nextInt();
		System.out.print("B�Է�>> ");
		int B = scan.nextInt();
		if(A==0&&B==0) {
			System.out.println("���α׷� ����");
			break;
		}else {
			System.out.println("���>> "+(A-B));
		}
		}
	}

}
