package pratice;

public class ex033�� {

	public static void main(String[] args) {
		int minus = 0;
		int plus = 0;
		for(int i =1; i<=100; i++) {
			if(i%2==0) {
				System.out.print("-"+i+" ");
				minus+=i;
			}else {
				System.out.print(i+" ");
				plus+=i;
			}
		}
		System.out.println();
		System.out.println("���: "+(plus-minus));

	}

}
