package pratice;

import java.util.Random;

public class ex187�� {

	public static void main(String[] args) {
		Random rd = new Random();
		int [] B = new int[6];
		
		for(int i=0;i<B.length; i++) {
			B[i] = rd.nextInt(45)+1;
			for (int j = 0; j<i; j++) {
				if(B[i]==B[j]) {
					i--;
				}
			}
		}
		for (int i = 0; i < B.length; i++) {
			System.out.println("����� ����: "+B[i]);
			
		}


	}

}
