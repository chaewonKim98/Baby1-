package pratice;

import java.util.Scanner;

public class ex2212�� {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int[] B = new int[5];
		
		for(int i=0; i<B.length; i++) {
			System.out.print(i+1+"��° �� �Է�>> ");
			B[i] = scan.nextInt();
		}

		System.out.println("���� ��");
		for(int i=0; i<B.length; i++) {
			for(int j=0; j<B.length-i-1; j++) {
				if(B[j]>B[j+1]) {
					int temp = B[j+1];
					B[j+1] = B[j];
					B[j] = temp;
				}
			}
		}
		for(int i=0; i<B.length; i++) {
			System.out.print(B[i]+" ");
		}

	}

}
