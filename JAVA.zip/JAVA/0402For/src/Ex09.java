import java.util.Scanner;

public class Ex09 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		//1~10���� �����
		int sum = 0;
		int num = scan.nextInt();
		for(int i = 1; i<=num; i++) {
			sum+=i;
			if(i<num) {
			System.out.print(i+"+");
			}else {
				System.out.print(i+"=");
			}
		}
		
		System.out.println(sum);
	}

}
