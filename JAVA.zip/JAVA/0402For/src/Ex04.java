
public class Ex04 {

	public static void main(String[] args) {
		for(char c = 'A'; c<='Z'; c++) {
			System.out.print(c + " ");
		}
		System.out.println();
		
		for (char i = 65; i<=90; i++) {
			System.out.print(i + " ");
		}
		
		
		
		
	}

}
