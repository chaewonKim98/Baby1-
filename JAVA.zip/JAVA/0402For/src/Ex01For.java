import java.util.Scanner;

public class Ex01For {
	public static void main(String[] args) {
		//1~5���� ���
		Scanner scan = new Scanner(System.in);
		
		for (int i = 1; i <= 3; i++) {
			System.out.print(i + " ");
		}
		
	}

}
