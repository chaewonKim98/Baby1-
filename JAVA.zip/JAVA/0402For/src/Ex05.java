
public class Ex05 {

	public static void main(String[] args) {
		
		//21~57 Ȧ�� ���
		//1��° ���
		for(int i = 21;i<=57;i+=2) {
			System.out.print(i+" ");
		}
		
		System.out.println();
		
		//2��° ���
		for(int j = 21; j<=57; j++) {
			if(j%2!=0) {
				System.out.print(j+" ");
			}
		}

	}

}
