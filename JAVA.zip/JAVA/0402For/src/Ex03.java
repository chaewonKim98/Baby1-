
public class Ex03 {

	public static void main(String[] args) {
		char c = '0';
		int temp = c;
		System.out.println(c);
		System.out.println(temp);

	}

}
