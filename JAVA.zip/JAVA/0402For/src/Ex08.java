import java.util.Scanner;

public class Ex08 {

	public static void main(String[] args) {
		
		//ġȯ
		int num3 = 10;
		int num4 = 15;
		System.out.println(num3+","+num4);
		
		int temp = num3;
		num3 = num4;
		num4 = temp;
		System.out.println(num3+","+num4);
		
		
		
		
		Scanner scan = new Scanner(System.in);
		System.out.print("ù ��° ���� �Է�>> ");
		int num1 = scan.nextInt();
		System.out.print("ù ��° ���� �Է�>> ");
		int num2 = scan.nextInt();
		
		if(num1>num2) {
			//ġȯ
			int temp1 = num1;
			num1 = num2;
			num2 = temp1;
		}
		for(int i = num1; i<=num2;i++) {
			System.out.println(i+" ");
		}

	}

}
