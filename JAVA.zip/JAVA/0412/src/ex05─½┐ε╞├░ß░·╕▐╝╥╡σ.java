
public class ex05ī���ð���޼ҵ� {

	public static void main(String[] args) {
		int[] array1 = { 1, 2, 3 };
		int[] array2 = { 1, 3, 2 };

		int[] sb = strikeBallCounting(array1, array2);
		arrayToString(sb);

	}

	public static void arrayToString(int[] array) {
		for (int num : array) {
			System.out.print(num+ " ");
		}
	}

	public static int[] strikeBallCounting(int[] array1, int[] array2) {
		int[] sb = new int[2];

		for (int i = 0; i < array1.length; i++) {
			if (array1[i] == array2[i]) {
				sb[0]++;
			}
			for (int j = 0; j < array2.length; j++) {

				if (array1[i] == array2[j]&& i!=j) {
					sb[1]++;
				}
			}
		}
		return sb;
	}

}
