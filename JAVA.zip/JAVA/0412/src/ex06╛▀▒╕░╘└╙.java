import java.util.Random;
import java.util.Scanner;

public class ex06�߱����� {

	public static void main(String[] args) {
		Random rd = new Random();
		Scanner scan = new Scanner(System.in);
		
		//1. ���� ������ �ִ� �迭 ����� ��������(�ߺ� ����)
		int [] randomArray = createRandomNumber(3);
		//2. ����ڰ� �Է��� ���� ������ �ִ� �迭(�Է�)
		int [] inputArray = new int[3];
		//3. strike, ball���� ������ �ִ� �迭
		int [] sb = new int[2];
		
		System.out.println("==GAME START==");
		arrayToString(randomArray);
		System.out.println();
		while(sb[0]!=3) {
			for(int i=0;i<inputArray.length;i++) {
				System.out.println(i+1+"��° ���� �Է�>> ");
				inputArray[i] = scan.nextInt();
			}
			sb = strikeBallCounting(randomArray, inputArray);
			System.out.println("Strike: "+sb[0]);
			System.out.println("Ball: "+sb[1]);
		}
		
	}
	public static boolean isDuplicate(int[] array) {
		boolean result = true;
		for (int i = 0; i < array.length; i++) {
			for (int j = i + 1; j < array.length; j++) {
				if (array[i] == array[j]) {
					result = true;
				} else {
					result = false;
				}
			}
		}
		return result;
	}

	public static int[] createRandomNumber(int i) {
		Random rd = new Random();
		int[] num = new int[i];
		do {
			for (int j = 0; j < num.length; j++) {
				num[j] = rd.nextInt(5) + 1;
			}
		} while (isDuplicate(num));

		return num;
	}
	public static void arrayToString(int[] array) {

		for (int num1 : array) {
			System.out.print(num1 + " ");
		}
	}
	public static int[] strikeBallCounting(int[] array1, int[] array2) {
		int[] sb = new int[2];

		for (int i = 0; i < array1.length; i++) {
			if (array1[i] == array2[i]) {
				sb[0]++;
			}
			for (int j = 0; j < array2.length; j++) {

				if (array1[i] == array2[j]&& i!=j) {
					sb[1]++;
				}
			}
		}
		return sb;
	}

}
