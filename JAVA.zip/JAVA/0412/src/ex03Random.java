import java.util.Random;

public class ex03Random {

	
	public static void main(String[] args) {
		int[] array = createRandomNumber(3);
		arrayToString(array);
		

	}
	public static int[] createRandomNumber(int i) {
		Random rd = new Random();
		int[] num = new int[i];
		
		for(int j =0; j<num.length; j++) {
			num[j] = rd.nextInt(5)+1;
			for (int k = 0; k < j; k++) {
				if (num[j] == num[k]) {
					j--;
				}
		}
		
		}
		return  num;
	}
	public static boolean isDuplicate(int[] array) {
		boolean result = true;
		for (int i = 0; i < array.length; i++) {
			for (int j = i+1; j < array.length; j++) {
				if(array[i]==array[j]) {
					result = true;
				}else {
					result = false;
				}
			}
		}
		return result;
	}
	public static void arrayToString(int[] array) {
		
		for(int num:array) {
			System.out.print(num+" ");
		}
	}

}
