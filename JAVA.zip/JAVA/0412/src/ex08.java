
public class ex08 {

	public static void main(String[] args) {
		int num = abs_Method(-5);
		System.out.println(num);
	}
	public static int abs_Method(int n) {
		int result = n; 
		
		if(n<=0) {
			result = n*-1;
		}
		
		
		return result;
	}

}
