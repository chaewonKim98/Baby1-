import java.util.Random;

public class ex04 {

	public static void main(String[] args) {
		int[] array = createRandomNumber(3);
		arrayToString(array);

	}

	public static boolean isDuplicate(int[] array) {
		boolean result = true;
		for (int i = 0; i < array.length; i++) {
			for (int j = i + 1; j < array.length; j++) {
				if (array[i] == array[j]) {
					result = true;
				} else {
					result = false;
				}
			}
		}
		return result;
	}

	public static int[] createRandomNumber(int i) {
		Random rd = new Random();
		int[] num = new int[i];
		do {
			for (int j = 0; j < num.length; j++) {
				num[j] = rd.nextInt(5) + 1;
			}
		} while (isDuplicate(num));

		return num;
	}

	public static void arrayToString(int[] array) {

		for (int num1 : array) {
			System.out.print(num1 + " ");
		}
	}
}
