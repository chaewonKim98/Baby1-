
public class ex02 {

	public static void main(String[] args) {
		int[] array = {2,7,3,5,4};
		boolean check = isDuplicate(array);
		System.out.println(check);

	}
	public static boolean isDuplicate(int[] array) {
		boolean result = true;
		for (int i = 0; i < array.length; i++) {
			for (int j = i+1; j < array.length; j++) {
				if(array[i]==array[j]) {
					result = true;
				}else {
					result = false;
				}
			}
		}
		return result;
	}

}
