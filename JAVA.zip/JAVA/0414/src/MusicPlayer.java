import java.util.ArrayList;

import javazoom.jl.player.MP3Player;

public class MusicPlayer {
	ArrayList<Music> musicList = new ArrayList<Music>();
	MP3Player mp3 = new MP3Player();
	int curIndex = 0;

	public MusicPlayer() {
		musicList.add(new Music("DallaDalla", "Itzy", 100, "C://music/Itzy - Dalla Dalla.mp3"));
		musicList.add(new Music("��", "Rain", 120, "C://music/Rain - ��.mp3"));
		musicList.add(new Music("SOLO", "Jennie", 200, "C://music/JENNIE - SOLO.mp3"));
		musicList.add(new Music("bad guy", "Billie Eilish", 200, "C://music/Billie Eilish - bad guy.mp3"));
		musicList.add(new Music("2002", "Anne Marie", 200, "C://music/Anne Marie - 2002.mp3"));
		musicList.add(new Music("Ring Ding Dong", "SHINee", 200, "C://music/SHINee - Ring Ding Dong.mp3"));
		musicList.add(new Music("FANCY", "TWICE", 200, "C://music/TWICE - FANCY.mp3"));
		// ���ο��� ��ü�� �������ڸ��� �뷡�� ����ȴ�
	}

	public Music play() {
		Music m = musicList.get(curIndex);
		if (mp3.isPlaying()) {
			mp3.stop();
		}
		mp3.play(m.getMusicPath());
		// �ּҰ���
		return m;
	}

	public Music nextPlay() {
		curIndex++;
		if (curIndex == musicList.size()) {
			curIndex = 0;
		}
		Music m = musicList.get(curIndex);
		mp3.play(m.getMusicPath());
		return m;
	}

	public Music prePlay() {
		curIndex--;
		if (curIndex < 0) {
			curIndex = musicList.size() - 1;
		}
		Music m = musicList.get(curIndex);
		mp3.play(m.getMusicPath());
		return m;
	}

	public String stop() {
		if (mp3.isPlaying()) {
			mp3.stop();
		}
		return "�뷡�� �����Ǿ����ϴ�.";
	}

}
