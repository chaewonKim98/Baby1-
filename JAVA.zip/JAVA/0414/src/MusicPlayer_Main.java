import java.util.Scanner;

import javazoom.jl.player.MP3Player;

public class MusicPlayer_Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		MusicPlayer player = new MusicPlayer();
		MP3Player mp3 = new MP3Player();
		
		while(true) {
			System.out.print("[1]��� [2]���� [3]������[4]������ [5]����>> ");
			int menu = scan.nextInt();
			if(menu==5) {
				player.stop();
				System.out.println("���α׷��� ����Ǿ����ϴ�.");
				break;
			}else if(menu==1) {
				Music m = player.play();
				System.out.println(Musicinfo(m));
			}else if(menu==3) {
				Music m = player.nextPlay();
				System.out.println(Musicinfo(m));
			}else if(menu==4) {
				Music m = player.prePlay();
				System.out.println(Musicinfo(m));
			}else if(menu==2) {
				String message = player.stop();
				System.out.println(message);
			}
		}

	}

	private static String Musicinfo(Music m) {
		return m.getSinger()+", "+m.getMusicName()+", "+changeTime(m);
	}

	private static String changeTime(Music m) {
		return m.getPlayTime()/60+"��"+m.getPlayTime()%60+"��";
	}

}
