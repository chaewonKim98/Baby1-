import java.util.Scanner;

public class ex04 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("���þ�>> ");
		String num1 = scan.next();
		
		while(true) {
			System.out.print("�ܾ �Է��� �ּ���>> ");
			String num = scan.next();
			String lastStr = num1.substring(num1.length()-1);
			String firstStr = num.substring(0,1);
			if(!lastStr.equals(firstStr)) {
				System.out.println("Ʋ�Ƚ��ϴ�.");
				break;
			}
			num1=num;
		}

	}

}
