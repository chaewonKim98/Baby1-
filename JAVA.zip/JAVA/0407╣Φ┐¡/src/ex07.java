
public class ex07 {

	public static void main(String[] args) {
		int[][] arr = new int[5][5];
//		System.out.println(arr[0][1]);
//		arr[0][1] =15;
//		System.out.println(arr[0][1]);
		int sum = 1;
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				arr[i][j]=sum;
				sum++;
				System.out.print(arr[i][j]+"\t");
			}System.out.println();
		}
		
		System.out.println();
		for(int k = 0; k<5; k++) {
			System.out.print(arr[0][k]+"\t");
		}
		
		
		
		
	}

}
