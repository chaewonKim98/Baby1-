import java.text.Bidi;

public class ex062��for�� {

	public static void main(String[] args) {
	//	int[][] intArray = new int[3][2];
		int[] pythonscore = new int[25];
		int[] java = new int[25];
		int[] DB = new int [25];
		
		int[][] bigdata = new int[3][25];
		System.out.println(bigdata.length);
		System.out.println(bigdata[0].length);
		
		System.out.println("============�ּ�============");
		System.out.println(bigdata);
		System.out.println(bigdata[0]);
		System.out.println(bigdata[1]);
		System.out.println(bigdata[2]);
		
		
		
		
		
		
		
	}

}
