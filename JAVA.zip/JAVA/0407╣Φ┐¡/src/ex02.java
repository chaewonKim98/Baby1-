import java.util.Scanner;

public class ex02 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int[] input = new int[5];
		int[] dab = {1,4,3,2,1};
		
		System.out.println("==ä���ϱ�==");
		System.out.println("���� �Է��ϼ���");
		int num = 0;

		for(int i = 0;i<input.length;i++) {
			num++;
			System.out.print(num+"����>> ");
			input[i] = scan.nextInt();
		}
		System.out.println("����Ȯ��");
		int cnt = 0;
		for(int i = 0; i<input.length;i++) {
			if(input[i]==dab[i]) {
				System.out.print("O"+" ");
				cnt+=20;
				
			}else {
				System.out.print("X"+" ");
			}
		}
		System.out.println("����: "+cnt);

	}

}
