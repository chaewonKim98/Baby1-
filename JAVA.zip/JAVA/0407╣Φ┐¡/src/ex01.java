import java.util.Scanner;

public class ex01 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int[] input = new int[5];
		
		System.out.println("==ä���ϱ�==");
		System.out.println("���� �Է��ϼ���");
		int num = 0;

		for(int i = 0;i<input.length;i++) {
			num++;
			System.out.print(num+"����>> ");
			input[i] = scan.nextInt();
		}
		System.out.print("�Է��� ��>> ");
		for(int i = 0; i<input.length;i++) {
			System.out.print(input[i]+" ");
		}
		
		
		
		
		

	}

}
