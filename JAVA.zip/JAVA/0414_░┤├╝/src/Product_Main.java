import java.util.ArrayList;
import java.util.Scanner;

public class Product_Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		ArrayList<Product> list = new ArrayList<Product>();
		int sum = 0;
		while (true) {
			System.out.print("[1]�����߰� [2]���� �Ǹŷ� ��ȸ [3]����>> ");
			int num = scan.nextInt();
			String name = "";
			int unitPrice = 0; 
			int amount = 0;
			if (num == 1) {

				System.out.print("�����̸�:");
				name = scan.next();
				System.out.print("�ܰ�: ");
				unitPrice = scan.nextInt();
				System.out.print("����: ");
				amount = scan.nextInt();
				Product p = new Product(name, unitPrice, amount);
				list.add(p);
			} else if (num == 2) {
				System.out.println("��ǰ��"+"\t"+"�ܰ�"+"\t"+"����");
				for(Product p: list) {
					System.out.println(p.getName()+"\t"+p.getUnitPrice()+"\t"+p.getAmount()+"��");
					sum+=p.getUnitPrice()*p.getAmount();
				}
				System.out.println("�Ǹ� �� ����: "+sum);
			} else if (num == 3) {
				break;
			}
		}

	}

}
