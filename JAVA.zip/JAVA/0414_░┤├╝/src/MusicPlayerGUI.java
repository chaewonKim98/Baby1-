import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.CardLayout;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;
import java.awt.SystemColor;

public class MusicPlayerGUI {

	private JFrame frame;
	MusicPlayer player = new MusicPlayer(); 

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MusicPlayerGUI window = new MusicPlayerGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MusicPlayerGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		//setBounds(x�� ��ġ, y����ġ, ����, ����)
		frame.setBounds(300, 300, 733, 365);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 255, 0));
		panel.setForeground(Color.GRAY);
		panel.setBounds(12, 21, 693, 137);
		frame.getContentPane().add(panel);
		panel.setLayout(new CardLayout(0, 0));
		
		JLabel lbl_musicinfo = new JLabel("Music Info");
		lbl_musicinfo.setForeground(Color.DARK_GRAY);
		lbl_musicinfo.setFont(new Font("����", Font.PLAIN, 22));
		lbl_musicinfo.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lbl_musicinfo, "name_250745144436200");
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.YELLOW);
		panel_1.setForeground(new Color(0, 0, 0));
		panel_1.setBounds(12, 166, 693, 137);
		frame.getContentPane().add(panel_1);
		
		JButton btn_pre = new JButton("\u25C0\u25C0");
		btn_pre.setBackground(new Color(255, 255, 0));
		btn_pre.setForeground(Color.GRAY);
		btn_pre.setFont(new Font("�޸ո���ü", Font.PLAIN, 22));
		btn_pre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Music m = player.prePlay();
				lbl_musicinfo.setText(Musicinfo(m));
			}
		});
		panel_1.setLayout(new GridLayout(0, 4, 0, 0));
		panel_1.add(btn_pre);
		
		JButton btn_play = new JButton("\u25B6");
		btn_play.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Music m = player.play();
				lbl_musicinfo.setText(Musicinfo(m)); 
			}
		});
		btn_play.setBackground(new Color(255, 255, 0));
		btn_play.setForeground(Color.GRAY);
		btn_play.setFont(new Font("�޸ո���ü", Font.PLAIN, 22));
		panel_1.add(btn_play);
		
		JButton btn_stop = new JButton("\u25A0");
		btn_stop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String message = player.stop();
				lbl_musicinfo.setText(message);
			}
		});
		btn_stop.setBackground(new Color(255, 255, 0));
		btn_stop.setForeground(Color.GRAY);
		btn_stop.setFont(new Font("�޸ո���ü", Font.PLAIN, 22));
		panel_1.add(btn_stop);
		
		JButton btn_next = new JButton("\u25B6\u25B6");
		btn_next.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Music m = player.nextPlay();
				lbl_musicinfo.setText(Musicinfo(m));
			}
		});
		btn_next.setBackground(new Color(255, 255, 0));
		btn_next.setForeground(Color.GRAY);
		btn_next.setFont(new Font("�޸ո���ü", Font.PLAIN, 22));
		panel_1.add(btn_next);
	}
	private static String Musicinfo(Music m) {
		return m.getSinger()+", "+m.getMusicName()+", "+changeTime(m);
	}

	private static String changeTime(Music m) {
		return m.getPlayTime()/60+"��"+m.getPlayTime()%60+"��";
	}
}
