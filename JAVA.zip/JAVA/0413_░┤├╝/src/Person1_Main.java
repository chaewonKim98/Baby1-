
public class Person1_Main {

	public static void main(String[] args) {
		Person1 p1 = new Person1("ä��ä��",20);
		Person1 p2 = new Person1("ää",24);
		Person1 p3 = new Person1("������",19);
		
		Person1[] personArr = new Person1[3];
		personArr[0] = p1;
		personArr[1] = p2;
		personArr[2] = p3;
		
		for (int i = 0; i < personArr.length; i++) {
			System.out.println(personArr[i].getName()+", "+personArr[i].getAge());
		}
	}

}
