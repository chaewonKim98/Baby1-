
public class Person_Main {

	public static void main(String[] args) {
		Person p1 = new Person();
		p1.name = "��ä";
		p1.age = 24;
		
		
		Person p2 = new Person("�ּ���",21);
		Person p3 = new Person("�ּ���");
}

}
