
public class PiggyBank_Main {

	public static void main(String[] args) {
		PiggyBank pd = new PiggyBank();
		
		
		pd.deposit(1000);
		System.out.println("���� �ܾ�: "+pd.showMoney());
		pd.withdraw(500);
		System.out.println("���� �ܾ�: "+pd.showMoney());
		
		//pd.money = 10000000;
		
	}

}
