
public class Student_Main {

	public static void main(String[] args) {
		Student student1 = new Student();
		student1.name = "ȫ�浿";
		student1.number = "20150675";
		student1.age = 22;
		student1.scoreJava = 50;
		student1.scoreWeb = 89;
		student1.scoreAndroid = 77;
		
		student1.show();
		
		Student student2 = new Student();
		student2.name = "�迵��";
		student2.number = "20090541";
		student2.age = 29;
		student2.scoreJava = 90;
		student2.scoreWeb = 25;
		student2.scoreAndroid = 30;
		System.out.println("==============================");
		
		student2.show();
	}

}
