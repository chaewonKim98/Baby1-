package ��¥�ڹ��佺Ƽ��;

import java.util.Scanner;

public class ex070������ {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		while(true) {
			System.out.print("A�Է�>> ");
			int A = scan.nextInt();
			System.out.print("B�Է�>> ");
			int B = scan.nextInt();
			if(A!=0&&B!=0) {
				System.out.println("���>> "+(A-B));
			}else if(A==0&&B==0) {
				break;
			}
		}

	}

}
