package ��¥�ڹ��佺Ƽ��;

public class ex09���̾Ƹ�� {

	public static void main(String[] args) {
		int[][] B = new int[4][7];
		int num1 = 0;
		int num2 = 1;
		for(int i=0; i<1; i++) {
			for(int j=0; j<7; j++) {
				if(i!=3) {
					B[i][j] = num1;
				}else {
					B[i][j] = num2;
				}
			}
		}
		for (int i = 0; i < B.length; i++) {
			for (int j = 0; j < B.length; j++) {
				System.out.print(B[i][j]);
			}
			System.out.println();
		}

	}

}
