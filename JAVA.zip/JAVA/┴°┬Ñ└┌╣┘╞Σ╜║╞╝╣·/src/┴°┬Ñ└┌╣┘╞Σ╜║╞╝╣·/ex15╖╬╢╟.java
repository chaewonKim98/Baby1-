package ��¥�ڹ��佺Ƽ��;

import java.util.Random;

public class ex15�ζ� {

	public static void main(String[] args) {
		Random rd = new Random();
		int[] B = new int[6];
		
		for(int i=0;i<B.length; i++) {
			System.out.print("����� ����: ");
			int num = rd.nextInt(50)+1;
			B[i] = num;
			int temp = num;
			if(B[i]==temp) {
				num--;
			}else {
				break;
			}
			System.out.println(B[i]);
		}

	}

}
