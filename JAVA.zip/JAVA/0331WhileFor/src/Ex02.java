import java.util.Scanner;

public class Ex02 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		while (true) {
			System.out.print("�����Է�>> ");
			int num = scan.nextInt();
			if (num>=10){
				System.out.println("����Ǿ����ϴ�.");
				break;
			}
			
		}

	}

}
