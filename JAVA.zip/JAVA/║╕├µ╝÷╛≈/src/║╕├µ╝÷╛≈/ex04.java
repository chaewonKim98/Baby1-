package �������;

import java.util.Scanner;

public class ex04 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int J = 0;
		int H = 0;
		for(int i = 1; i<=10; i++) {
			int num = scan.nextInt();
			if(num%2==0) {
				J++;
			}else {
				H++;
			}
			System.out.println("Ȧ�� ����: "+H);
			System.out.println("¦�� ����: "+J);
		}
		
		
	}

}
