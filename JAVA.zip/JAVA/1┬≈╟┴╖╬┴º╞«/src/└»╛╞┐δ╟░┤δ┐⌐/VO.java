package ���ƿ�ǰ�뿩;

public class VO {
	String id;
	String pw;
	String name;
	String phonenumber;
	String address;
	String account;
	String money;
	String pname;
	String pnumber;
	String bigctg;
	String smallctg;
	String currentprice;
	String rstate;
	String rstart;
	String rfinish;
	String latepayment;
	String tpmoney;
	String epayback;
	String deposit;
	String rmonth;
	String rmoney;
	String rnumber;
	
	
	
	
	public VO(String id, String pnumber, String rstart, String rfinish, String latepayment, String tpmoney,
			String epayback) {
		super();
		this.id = id;
		this.pnumber = pnumber;
		this.rstart = rstart;
		this.rfinish = rfinish;
		this.latepayment = latepayment;
		this.tpmoney = tpmoney;
		this.epayback = epayback;
	}
	public VO(String pname, String pnumber, String bigctg, String smallctg, String currentprice, String rstate) {
		super();
		this.pname = pname;
		this.pnumber = pnumber;
		this.bigctg = bigctg;
		this.smallctg = smallctg;
		this.currentprice = currentprice;
		this.rstate = rstate;
	}
	public String getId() {
		return id;
	}
	public String getPw() {
		return pw;
	}
	public String getName() {
		return name;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public String getAddress() {
		return address;
	}
	public String getAccount() {
		return account;
	}
	public String getMoney() {
		return money;
	}
	public String getPname() {
		return pname;
	}
	public String getPnumber() {
		return pnumber;
	}
	public String getBigctg() {
		return bigctg;
	}
	public String getSmallctg() {
		return smallctg;
	}
	public String getCurrentprice() {
		return currentprice;
	}
	public String getRstate() {
		return rstate;
	}
	public String getRstart() {
		return rstart;
	}
	public String getRfinish() {
		return rfinish;
	}
	public String getLatepayment() {
		return latepayment;
	}
	public String getTpmoney() {
		return tpmoney;
	}
	public String getEpayback() {
		return epayback;
	}
	public String getDeposit() {
		return deposit;
	}
	public String getRmonth() {
		return rmonth;
	}
	public String getRmoney() {
		return rmoney;
	}
	public String getRnumber() {
		return rnumber;
	}
	

	
	
}
