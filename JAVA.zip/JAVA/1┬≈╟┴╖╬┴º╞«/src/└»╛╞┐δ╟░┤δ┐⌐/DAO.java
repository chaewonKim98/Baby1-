package ���ƿ�ǰ�뿩;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;




public class DAO {
	Connection conn = null;
	PreparedStatement psmt = null;
	ResultSet rs = null;
	int cnt = 0;
	String sql = "";
	VO vo = null;
	VOreturn VOreturn = null;
	public void getConn() {
		try {
			String url = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
			String dbid = "hr";
			String dbpw = "hr";

			Class.forName("oracle.jdbc.driver.OracleDriver");

			conn = DriverManager.getConnection(url, dbid, dbpw);
		} catch (Exception e) {

		}
	}

	public int insert_C(String id, String pw, String name, String phonenumber, String address,String account,String money) {

		try {

			getConn();
			sql = "insert into customer values(?,?,?,?,?,?,?)";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, id);
			psmt.setString(2, pw);
			psmt.setString(3, name);
			psmt.setString(4, phonenumber);
			psmt.setString(5, address);
			psmt.setString(6, account);
			psmt.setString(7, money);

			cnt = psmt.executeUpdate();
		} catch (Exception e) {

		}
		return cnt;
	}

	public ArrayList<VO> select_P() {
		ArrayList<VO> arr = new ArrayList<VO>();
		try {
			getConn();
			sql = "Select pname, pnumber, bigctg, smallctg, currentprice, rstate from production";
			psmt = conn.prepareStatement(sql);
			
			rs = psmt.executeQuery();
			
			
			while(rs.next()) {
				String pname = rs.getString(1);
				String pnumber = rs.getString(2);
				String bigctg = rs.getString(3);
				String smallctg = rs.getString(4);
				String currentprice = rs.getString(5);
				String rstate = rs.getString(6);
				
				vo = new VO(pname, pnumber, bigctg, smallctg,currentprice, rstate);
				
				arr.add(vo);
				
			}
			
		} catch (Exception e) {
		
			System.out.println("try������ �����߻�");
			e.printStackTrace();
		}
		return arr;
	}
	

	public int delete_P(String pnumber) {

		try {
			getConn();
			sql = "delete from production where pnumber=?";
			psmt = conn.prepareStatement(sql);

			psmt.setString(1, pnumber);
			cnt = psmt.executeUpdate();

		} catch (Exception e) {
			System.out.println("try���� ������ �߻��߽��ϴ�.");
			e.printStackTrace();
		}
		return cnt;
	}
	public int insert_P(String pnumber, String pname, String currentprice, String monthmoney, String pdetail,String bigctg, String smallctg, String rcount, String rstate) {

		try {

			getConn();
			sql = "insert into production values(?,?,?,?,?,?,?,?,?)";
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, pnumber);
			psmt.setString(2, pname);
			psmt.setString(3, currentprice);
			psmt.setString(4, monthmoney);
			psmt.setString(5, pdetail);
			psmt.setString(6, bigctg);
			psmt.setString(7, smallctg);
			psmt.setString(8, rcount);
			psmt.setString(9, rstate);
			

			cnt = psmt.executeUpdate();
		} catch (Exception e) {

		}
		return cnt;
	}
	public ArrayList<VO> select_R() {
		ArrayList<VO> arr = new ArrayList<VO>();
		try {
			getConn();
			sql = "Select customer_id, production_pnumber, rstart, rfinish, latepayment, tpmoney,epayback from rent";
			psmt = conn.prepareStatement(sql);
			
			rs = psmt.executeQuery();
			while(rs.next()) {
				String ID = rs.getString(1);
				String pnumber = rs.getString(2);
				String rstart = rs.getString(3);
				String rfinish = rs.getString(4);
				String latepayment = rs.getString(5);
				String tpmoney = rs.getString(6);
				String epayback = rs.getString(7);
				
				vo = new VO(ID, pnumber, rstart, rfinish,latepayment, tpmoney,epayback);
				
				arr.add(vo);
				
			}
			
		} catch (Exception e) {
		
			System.out.println("try������ �����߻�");
			e.printStackTrace();
		}
		return arr;
	}
	public ArrayList<VOreturn> select_T() {
		ArrayList<VOreturn> arr = new ArrayList<VOreturn>();
		try {
			getConn();
			sql = "Select rnumber, deposit, rmonth, rmoney, tpmoney,latepayment ,epayback  from rent where rback ='�ݳ���û'";
			psmt = conn.prepareStatement(sql);
			
			rs = psmt.executeQuery();
			while(rs.next()) {
				String rnumber = rs.getString(1);
				String deposit = rs.getString(2);
				String rmonth = rs.getString(3);
				String rmoney = rs.getString(4);
				String tpmoney = rs.getString(5);
				String latepayment = rs.getString(6);
				String epayback = rs.getString(7);
				
				VOreturn = new VOreturn(rnumber, deposit, rmonth, rmoney,tpmoney, latepayment,epayback);
				
				arr.add(VOreturn);
				
			}
			
		} catch (Exception e) {
		
			System.out.println("try������ �����߻�");
			e.printStackTrace();
		}
		return arr;
	}


}
