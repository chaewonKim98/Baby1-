package JDBC;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.PseudoColumnUsage;
import java.util.Scanner;

public class ex01insert implements Rule_interFace{

	public void execute(){
		Scanner scan = new Scanner(System.in);
		System.out.print("ID>> ");
		String id = scan.next();
		System.out.print("PW>> ");
		String pw = scan.next();
		System.out.print("TEL>> ");
		String tel = scan.next();
		System.out.print("EMAIL>> ");
		String email = scan.next();
		System.out.print("ADD>> ");
		String add = scan.next();
		
		DAO dao = new DAO();
		int cnt = dao.DAO_insert(id, pw, tel, email, add);
		
		
		if(cnt>0) {
			System.out.println("�Է¼���");
		}else {
			System.out.println("�Է½���");
		}
		
	}

}
