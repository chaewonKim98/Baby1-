package JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class ex07OneSelect implements Rule_interFace {
	public void execute() {
		// ����ڿ��� id���� �Է¹޾Ƽ�
		// �ش� id���� �����͸� �˻��Ͻÿ�
		Scanner scan = new Scanner(System.in);
		System.out.print("ID�� �Է�>> ");
		String id = scan.next();
		DAO dao = new DAO();
		VO vo = dao.DAO_oneSelect(id);
	
		System.out.println("ID : " + vo.getId());
		System.out.println("PW : " + vo.getPw());
		System.out.println("TEL : " + vo.getTel());
		System.out.println("EMAIL : " + vo.getEmail());
		System.out.println("ADDRESS : " + vo.getAddress());
		System.out.println("------------------");

	}
}
