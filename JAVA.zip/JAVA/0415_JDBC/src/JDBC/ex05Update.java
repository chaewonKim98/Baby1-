package JDBC;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class ex05Update implements Rule_interFace{

	public void execute() {
		Scanner sc = new Scanner(System.in);
	      System.out.print("ID>>");
	      String id = sc.next();
	      System.out.print("CHOICE>>");
	      String choice = sc.next();   
	      System.out.print("DATA>>");
	      String data = sc.next();
	      DAO dao = new DAO();
	      int cnt = dao.DAO_update(id ,choice, data); 
	         if(cnt>0) {
	            System.out.println("��������");
	         }else {
	            System.out.println("��������");
	         }
	}

}
