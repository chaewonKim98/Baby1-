package ClassMethod;

import java.util.Scanner;

public class Minus���� {

	public int min(int num1, int num2) {
		int result = num1-num2;
		return result;
	}

}
