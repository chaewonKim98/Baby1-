package BabyProductsRental;

public class chartVO {
	String head;
	String rank;
	
	public chartVO(String head, String rank) {
		super();
		this.head = head;
		this.rank = rank;
	}

	public String getHead() {
		return head;
	}

	public void setHead(String head) {
		this.head = head;
	}

	public String getRank() {
		return rank;
	}

	public void setRank(String rank ){
		this.rank = rank;
	}


}
