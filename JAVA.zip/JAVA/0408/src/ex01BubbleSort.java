import java.util.Arrays;

public class ex01BubbleSort {

	public static void main(String[] args) {

//		int[] arr = { 5, 4, 3, 2, 1 };// ��5
//
//		System.out.println(Arrays.toString(arr));
//
//		for (int k = 0; k < arr.length - 1; k++) { // 0->3���� 0,1,2,3 4�� �ݺ�
//			for (int i = 0; i < arr.length - 1; i++) {//
//				if (arr[i] > arr[i + 1]) {
//					int temp = arr[i];
//					arr[i] = arr[i + 1];
//					arr[i + 1] = temp;
//				}
//			}
//		}
//
//		System.out.println(Arrays.toString(arr));
//		
		//������������
		int[] arr = { 5, 4, 3, 2, 1 };// ��5
		
		for(int i=0;i<arr.length;i++) {
			for(int j =0;j<arr.length-1;j++) {
				if(arr[j]>arr[j+1]) {
					int temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
				}
			}
		}
		System.out.println(Arrays.toString(arr));
		for(int num: arr) {
			System.out.print(num+" ");
		}
		
		
		
		
		
		
		
		
		
		

	}

}
