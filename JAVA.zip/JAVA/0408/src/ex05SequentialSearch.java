
public class ex05SequentialSearch {

	public static void main(String[] args) {
		int[] arr = {13,35,15,11,26,72,78,13,61,90};
		int search = 78;
		int i = 0;
			for(i = 0; i<arr.length;i++) {
				System.out.print(arr[i]+" ");
				if(search == arr[i]) {
				}
			}
			System.out.println();
			System.out.println(search+"��(��) "+i+"��° �����Դϴ�.");
			
			
			
		
		
		
		

	}

}
