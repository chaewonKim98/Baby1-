
public class Person_Main {

	public static void main(String[] args) {
		Student student = new Student("ää", 24);
		Teacher teacher = new Teacher("��", 78, 5000);
		
		//�迭 ����(���� 2)
		Person[] arr = new Person[2];
		arr[0] = student;
		arr[1] = teacher;
		
		for(Person p :arr) {
			System.out.println("�̸�: "+p.getName());
			System.out.println("����: "+p.getJob());
			System.out.println("����: "+p.getAge());
			System.out.println();
		}
		//student�� study() ȣ��
		Student student2 = (Student)arr[0];
		student2.study();
		
		Teacher teacher2=(Teacher)arr[1];
		teacher2.getPay();
		teacher2.teach();
	}

}
